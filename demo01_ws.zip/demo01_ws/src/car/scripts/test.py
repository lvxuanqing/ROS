#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import Twist
import math

PI = 3.1415926

def main():
    # 2、初始化 ROS 节点；
    rospy.init_node("mycontrol")
    # 3、创建节点句柄；
    nh = rospy.NodeHandle()
    # 4、创建发布对象
    pub = nh.advertise("/turtle1/cmd_vel", Twist, queue_size=10)
    # 5、发布逻辑实现
    rate = rospy.Rate(1)  

    twist = Twist()
    # 参数设置
    linear_x = 0.0
    angular_z = 0.0
    count = 0  # 计数
    
    twist.linear.x = 0.0  # 前后
    twist.angular.z = 0.0  # 偏航

    while not rospy.is_shutdown():
        
        if count == 0:
            linear_x = 0
            angular_z = PI/3
            count+=1

 
        if count == 1:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 2:
            linear_x = 0
            angular_z = -2*PI/3
            count+=1
        if count == 3:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 4:  
            angular_z = 2*PI/3
            linear_x = 0 
        if count == 5:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 6:
            linear_x = 0
            angular_z = -2*PI/3
            count+=1
        if count == 7:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 8:  
            angular_z = 2*PI/3
            linear_x = 0 
        if count == 9:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 10:
            linear_x = 0
            angular_z = -2*PI/3
            count+=1
        if count == 11:
            angular_z = 0
            linear_x = 4.0
            count +=1
        if count == 12:  
            angular_z = 2*PI/3
            linear_x = 0 
            count +=1


       
        if count == 13:
            linear_x = 8
            angular_z = 0

        twist.linear.x = linear_x  # 前后
        twist.angular.z = angular_z  # 偏航
        pub.publish(twist)  # 发布

        # 休眠
        rate.sleep()

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass

